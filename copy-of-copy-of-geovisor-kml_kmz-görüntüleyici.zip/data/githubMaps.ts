
// Buraya GitHub'a yüklediğiniz dosyaların "Raw" linklerini ekleyin.
// Örnek: 'https://raw.githubusercontent.com/kullaniciadi/reponame/main/harita.kmz'
export const githubMaps = [
  // Şimdilik boş veya test amaçlı bir link bırakabilirsiniz.
  // Kendi linkinizi buraya eklediğinizde uygulama açılışta bunu yükleyecektir.
];
